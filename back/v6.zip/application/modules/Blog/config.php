<?php

/*
Module Icon: <i class="glyphicon glyphicon-th-large"></i>
Module Name: Blog
Module Display Name: Blog
Admin Menu: <li><a href="%baseurl%admin/blog/"> Posts</a></li><li><a href="%baseurl%admin/blog/category/"> Blog Categories</a></li><li class="divider"></li><li><a href="%baseurl%admin/blog/settings/"> Blog Settings</a></li>
Version: 1.0
*/