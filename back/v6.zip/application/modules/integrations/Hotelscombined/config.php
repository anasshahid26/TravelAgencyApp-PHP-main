<?php

/*
Module Icon: <i class="fa fa-building"></i>
Module Name: hotelscombined
Module Display Name: Hotels Combined
Admin Menu: <li><a href="%baseurl%admin/hotelscombined/settings/"><span class="fa fa-building"></span> Hotels Combined </a></li>
Integration: Yes
Version: 1.0
*/