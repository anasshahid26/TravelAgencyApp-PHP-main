<?php

/*
Module Icon: <i class="fa fa-plane"></i>
Module Name: travelstart
Module Display Name: TravelStart Flights
Admin Menu: <li><a href="%baseurl%admin/travelstart/settings/"><span class="fa fa-plane"></span> Travel Start</a></li>
Integration: Yes
Version: 1.0
*/