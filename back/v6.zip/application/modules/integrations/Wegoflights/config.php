<?php

/*
Module Icon: <i class="fa fa-plane"></i>
Module Name: wegoflights
Module Display Name: Wego Flights
Admin Menu: <li><a href="%baseurl%admin/wegoflights/settings/"><span class="fa fa-plane"></span> Wego Flights </a></li>
Integration: Yes
Version: 1.0
*/