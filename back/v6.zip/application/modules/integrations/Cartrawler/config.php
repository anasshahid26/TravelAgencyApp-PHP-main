<?php

/*
Module Icon: <i class="fa fa-cab"></i>
Module Name: cartrawler
Module Display Name: Cartrawler
Admin Menu: <li><a href="%baseurl%admin/cartrawler/settings/"><span class="fa fa-plane"></span> Cartrawler</a></li>
Integration: Yes
Version: 1.0
*/