<?php

/*
Module Icon: <i class="fa fa-comments"></i>
Module Name: tripadvisor
Module Display Name: Trip Advisor
Admin Menu: <li><a href="%baseurl%admin/tripadvisor/settings/"><span class="fa fa-comments"></span> Trip Advisor </a></li>
Integration: Yes
Version: 1.0
*/