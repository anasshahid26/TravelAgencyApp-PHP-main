<?php

/*
Module Icon: <i class="fa fa-plane"></i>
Module Name: flightsdohop
Module Display Name: Dohop Flights
Admin Menu: <li><a href="%baseurl%admin/flightsdohop/settings/"><span class="fa fa-plane"></span> Flights Dohop</a></li>
Integration: Yes
Version: 1.0
*/