<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('testdohop'))
{

function testdohop(){  

}

}
