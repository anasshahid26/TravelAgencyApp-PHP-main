<?php

/*
Module Icon: <i class="fa fa-suitcase"></i>
Module Name: Tours
Module Display Name: Tours
Admin Menu: <li><a href="%baseurl%admin/tours/"> Tours</a></li><li><a href="%baseurl%admin/tours/add/"> Add New</a></li><li><a href="%baseurl%admin/tours/extras/"> Extras</a></li><li><a href="%baseurl%admin/tours/reviews/"> Reviews</a></li><li><a href="%baseurl%admin/tours/settings/"> Settings</a></li>
Supplier Menu: <li><a href="%baseurl%supplier/tours/"> Manage Tours</a></li><li><a href="%baseurl%supplier/tours/extras/"> Extras</a></li>
Version: 1.0
*/