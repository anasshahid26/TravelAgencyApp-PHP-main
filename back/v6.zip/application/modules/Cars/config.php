<?php

/*
Module Icon: <i class="fa fa-car"></i>
Module Name: Cars
Module Display Name: Cars
Admin Menu: <li><a href="%baseurl%admin/cars/"> Cars</a></li><li class="divider"></li><li><a href="%baseurl%admin/cars/extras/"> Extras</a></li><li><a href="%baseurl%admin/cars/settings/"> Cars Settings</a></li>
Supplier Menu: <li><a href="%baseurl%supplier/cars/"> Cars</a></li><li><a href="%baseurl%supplier/cars/extras/"> Extras</a></li>
Version: 1.0
*/