<?php

/*
Module Icon: <i class="fa fa-building-o"></i>
Module Name: Hotels
Module Display Name: Hotels
Admin Menu: <li><a href="%baseurl%admin/hotels/"></span>Hotels</a></li><li><a href="%baseurl%admin/hotels/rooms/"> Rooms</a></li><li><a href="%baseurl%admin/hotels/extras/"> Extras</a></li><li><a href="%baseurl%admin/hotels/reviews/"> Reviews</a></li><li><a href="%baseurl%admin/hotels/settings/"> Hotels Settings</a></li>
Supplier Menu: <li><a href="%baseurl%supplier/hotels/"> Manage Hotels</a></li><li class="divider"></li><li><a href="%baseurl%supplier/hotels/rooms/add/"> Add Room</a></li><li><a href="%baseurl%supplier/hotels/rooms/"> Manage Rooms</a><li><a href="%baseurl%supplier/hotels/extras/"> Extras</a></li></li>
Version: 1.5
*/