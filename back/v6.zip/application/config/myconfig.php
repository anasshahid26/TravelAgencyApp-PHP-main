<?php
$config['batmeezi'] = 'testing ;)';